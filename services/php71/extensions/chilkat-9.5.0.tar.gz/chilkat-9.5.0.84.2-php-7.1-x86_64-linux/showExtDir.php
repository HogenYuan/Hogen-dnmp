<?php

$extPath = ini_get("extension_dir");

print $extPath . "\n";


?>

